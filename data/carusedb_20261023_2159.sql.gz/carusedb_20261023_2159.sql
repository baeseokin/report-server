/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.0.2-MariaDB, for osx10.20 (arm64)
--
-- Host: localhost    Database: carusedb
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Current Database: `carusedb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `carusedb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `carusedb`;

--
-- Table structure for table `car_reservations`
--

DROP TABLE IF EXISTS `car_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reservation_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `driver_name` varchar(100) NOT NULL,
  `passenger_count` int(11) DEFAULT 1,
  `destination` varchar(255) DEFAULT NULL,
  `purpose` text NOT NULL,
  `status` enum('RESERVED','IN_PROGRESS','COMPLETED','CANCELLED') DEFAULT 'RESERVED',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_res_car` (`car_id`),
  KEY `fk_res_user` (`user_id`),
  CONSTRAINT `fk_res_car` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_res_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car_reservations`
--

LOCK TABLES `car_reservations` WRITE;
/*!40000 ALTER TABLE `car_reservations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `car_reservations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `car_usage_logs`
--

DROP TABLE IF EXISTS `car_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) DEFAULT NULL,
  `car_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `drive_date` date NOT NULL,
  `departure_place` varchar(100) DEFAULT '교회',
  `departure_time` time NOT NULL,
  `destination_place` varchar(200) NOT NULL,
  `destination_address` varchar(255) DEFAULT NULL,
  `dest_lat` decimal(10,7) DEFAULT NULL,
  `dest_lng` decimal(10,7) DEFAULT NULL,
  `arrival_time` time NOT NULL,
  `distance_km` decimal(8,2) NOT NULL DEFAULT 0.00,
  `accumulated_km` int(11) DEFAULT NULL,
  `organization_and_passengers` varchar(255) DEFAULT NULL,
  `driver_name` varchar(100) NOT NULL,
  `approval_status` enum('DRAFT','SUBMITTED','APPROVED') DEFAULT 'SUBMITTED',
  `memo` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_log_car` (`car_id`),
  KEY `fk_log_res` (`reservation_id`),
  KEY `fk_log_user` (`user_id`),
  CONSTRAINT `fk_log_car` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_log_res` FOREIGN KEY (`reservation_id`) REFERENCES `car_reservations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car_usage_logs`
--

LOCK TABLES `car_usage_logs` WRITE;
/*!40000 ALTER TABLE `car_usage_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `car_usage_logs` VALUES
(1,NULL,1,NULL,'2026-08-20','교회','12:00:00','서울 목동',NULL,NULL,NULL,'14:10:00',15.00,NULL,'교회 심방 4명','김수겸','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(2,NULL,1,NULL,'2026-08-21','교회','12:30:00','제일 버거',NULL,NULL,NULL,'12:35:00',2.00,NULL,'1교구 8명','지성일','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(3,NULL,1,NULL,'2026-08-21','교회','12:00:00','수색 흐름식당',NULL,NULL,NULL,'14:00:00',8.50,NULL,'교역자 김영실','유준성','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(4,NULL,1,NULL,'2026-08-21','교회','14:00:00','삼성강북병원',NULL,NULL,NULL,'14:40:00',12.00,NULL,'송혜숙 권사님 2명','유준성','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(5,NULL,1,NULL,'2026-08-28','교회','10:00:00','솔틴비전센터',NULL,NULL,NULL,'13:10:00',25.00,NULL,'청년부 리트릿','김진호','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(6,NULL,1,NULL,'2026-08-30','교회','18:00:00','일산 쿠우쿠우',NULL,NULL,NULL,'21:00:00',32.00,NULL,'김부헌 외 8명','김부헌','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(7,NULL,1,NULL,'2026-09-11','교회','12:10:00','고구려식사',NULL,NULL,NULL,'14:25:00',16.00,NULL,'구역장 모임','김수겸','SUBMITTED',NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49');
/*!40000 ALTER TABLE `car_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_name` varchar(100) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `model` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT 12,
  `fuel_type` varchar(50) DEFAULT '디젤',
  `current_total_km` int(11) DEFAULT 0,
  `status` enum('AVAILABLE','IN_USE','MAINTENANCE') DEFAULT 'AVAILABLE',
  `image_url` varchar(255) DEFAULT NULL,
  `memo` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `plate_number` (`plate_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cars` VALUES
(1,'스타렉스 1호','8051','현대 그랜드 스타렉스 12인승',12,'디젤',85400,'AVAILABLE',NULL,NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(2,'카니발 2호','7560','기아 올뉴 카니발 9인승',9,'디젤',42100,'AVAILABLE',NULL,NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(3,'스타리아 3호','5600','현대 스타리아 라운지 9인승',9,'하이브리드',18300,'AVAILABLE',NULL,NULL,'2026-09-12 04:21:49','2026-09-12 04:21:49');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `role` enum('ADMIN','USER') DEFAULT 'USER',
  `is_approved` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'admin','$2b$10$wO3Y121N1QfIkgx6vOcgquC7441BvhQxI7x9R5cE2fB851G7h6fPq','관리자','010-1234-5678','관리부','ADMIN',1,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(2,'driver1','$2b$10$wO3Y121N1QfIkgx6vOcgquC7441BvhQxI7x9R5cE2fB851G7h6fPq','김수겸','010-2222-3333','차량관리팀','USER',1,'2026-09-12 04:21:49','2026-09-12 04:21:49'),
(3,'driver2','$2b$10$wO3Y121N1QfIkgx6vOcgquC7441BvhQxI7x9R5cE2fB851G7h6fPq','지성일','010-3333-4444','1교구','USER',1,'2026-09-12 04:21:49','2026-09-12 04:21:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'carusedb'
--

--
-- Dumping routines for database 'carusedb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-23 21:59:41
