INSERT INTO reportdb.roles (role_name) VALUES
	 ('관리자'),
	 ('당회장'),
	 ('부장'),
	 ('위원장'),
	 ('재정부'),
	 ('회계');
