INSERT INTO reportdb.users (user_id,user_name,email,phone,dept_name,password_hash,created_at) VALUES
	 ('user01','관리자','2222@naver.com','1','교회','$2b$10$PY2LIFazvdE0DL4BG4YHhu76Zc5SSsApp.qIdFNBVBUWi/.lr82K6','2025-09-04 12:06:35'),
	 ('user02','배석인','','','원천엔젤스','$2b$10$RdUwLN765Y/.TwU5reKSI.AsnMFD4F0xUDnePgxY8nficBw5inJrC','2025-09-04 12:49:28'),
	 ('user03','김개욱','2222@ee.com','','음악부','$2b$10$ous4ef/ISKhaiqa08hwpfOIOYveBa9s/6Yo0RkTbBpc/grKJsuu3O','2025-09-05 12:20:09'),
	 ('user04','이종민','','','음악부','$2b$10$HyUcMFCuyTL5T2TLb6QY/eVHssikD3RSJQ2yd/f5JGbuWThogsrOa','2025-09-05 12:20:49'),
	 ('user05','재정부','','','재정부','$2b$10$Kt6.tcqzEDaid95P2MApmuMczv.MEtlpGH11aisgRrMi1IIE4pMqi','2025-09-05 14:01:21');
