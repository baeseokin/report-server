INSERT INTO reportdb.dept_approvers (dept_name,`role`,approver_name,approver_user_id,approver_order,is_active,created_at) VALUES
	 ('원천엔젤스','담당','배석인','user02',1,1,'2025-09-05 12:05:45'),
	 ('원천엔젤스','부장','김개욱','user03',2,1,'2025-09-05 12:06:46'),
	 ('원천엔젤스','위원장','이종민','user04',3,1,'2025-09-05 12:06:48');
