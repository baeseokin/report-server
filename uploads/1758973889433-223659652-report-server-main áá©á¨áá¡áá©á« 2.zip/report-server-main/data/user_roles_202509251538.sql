INSERT INTO reportdb.user_roles (user_id,role_id) VALUES
	 (1,1),
	 (3,2),
	 (4,3),
	 (5,4),
	 (8,6);
