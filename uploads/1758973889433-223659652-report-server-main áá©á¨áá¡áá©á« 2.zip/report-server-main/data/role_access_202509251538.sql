INSERT INTO reportdb.role_access (role_id,menu_name,access_type) VALUES
	 (1,'계정과목 관리','all'),
	 (1,'권한 관리','all'),
	 (1,'내결재목록 조회','all'),
	 (1,'보고서 작성','all'),
	 (1,'사용자 관리','all'),
	 (1,'예산 관리','all'),
	 (1,'예산집행 현황','all'),
	 (1,'청구목록 조회','all'),
	 (2,'보고서 작성','all'),
	 (2,'청구목록 조회','all');
INSERT INTO reportdb.role_access (role_id,menu_name,access_type) VALUES
	 (3,'내결재목록 조회','all'),
	 (3,'청구목록 조회','all'),
	 (4,'내결재목록 조회','all'),
	 (4,'청구목록 조회','all'),
	 (5,'내결재목록 조회','all'),
	 (5,'청구목록 조회','all'),
	 (6,'내결재목록 조회','all'),
	 (6,'보고서 작성','all'),
	 (6,'청구목록 조회','all');
